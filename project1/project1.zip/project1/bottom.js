const bottom = () => `
</body>
</html>
`;

module.exports = bottom;
